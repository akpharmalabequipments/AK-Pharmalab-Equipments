AK PHARMALAB EQUIPMENTS - WEBSITE
=================================

Files:
- index.html : complete responsive website
- assets/logo.svg : editable SVG logo

HOW TO PUBLISH FOR FREE
1. Open https://pages.github.com/ or https://www.netlify.com/
2. Create a free account.
3. Upload this website (index.html + assets folder).
4. Publish as a static website.
5. You can later connect your own .com domain.

IMPORTANT:
- The contact form opens WhatsApp; no paid form backend is required.
- Replace/update product images, specifications, certificates and company text as needed.
- The WhatsApp number and email currently use the details supplied for AK Pharmalab Equipments.
